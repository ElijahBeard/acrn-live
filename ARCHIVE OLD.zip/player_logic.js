document.addEventListener('DOMContentLoaded', function() {
    var slider = document.getElementById("bar");
    slider.oninput = function() {
        console.log(slider.value / 100);
        const audio = document.getElementById('streamAudio');
        audio.volume = (slider.value / 100);
    }
});

function b_pause(){
    console.log("played");
    const playbutton = document.getElementById("play")
    playbutton.innerHTML = '<i class="fa-solid fa-play"></i>';
}
function b_play(){
    console.log("paused");
    const playbutton = document.getElementById("play")
    playbutton.innerHTML = '<i class="fa-solid fa-pause"></i>';
}